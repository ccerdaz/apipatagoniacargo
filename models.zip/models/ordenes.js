module.exports = (sequelize, type) => {
    return sequelize.define('ordenes', {
        Id: { // Corresponde al campo N° de la planilla del cliente 
            type: type.INTEGER,
            primaryKey: true,
            // autoIncrement: true
        },
        FechaRetiro: type.DATE,
        TipoServicio: type.STRING,
        Origen: type.STRING,
        Destino: type.STRING,
        FormaPago: type.STRING,
        RemitenteODestino: type.STRING,
        IdCliente: type.INTEGER,
        Cliente: type.STRING,
        DocumentoAdjunto: { type: type.STRING, defaultValue: 'SIN DOC' },
        ValorDeclarado: type.INTEGER,
        Sobre: type.STRING, // Se desconoce su uso
        Piezas: type.INTEGER,
        Peso: type.INTEGER,
        Ancho: type.INTEGER,
        Largo: type.INTEGER,
        Alto: type.INTEGER,
        PesoVolumen: type.INTEGER,
        PesoCobrado: type.INTEGER,
        TarifaAplicada: type.INTEGER,
        FleteCobrado: type.INTEGER,
        Seguro: type.INTEGER,
        OtrosCargos: type.INTEGER,
        Neto: type.INTEGER,
        Iva: type.INTEGER,
        Total: type.INTEGER,
        Check: type.BOOLEAN,
        NumeroFactura: type.INTEGER,
        Observacion: type.STRING(255),
        Pod: type.STRING(50), //Se desconoce su uso
        ImpresionRespaldo: type.STRING(50), //Se desconoce su uso
        FacturaEnviada: { type: type.BOOLEAN, defaultValue: false },
        ImpresionRespaldo: type.STRING(50), //Se desconoce su uso
        TransDocEfectivo: type.STRING(50),
        PagadoA: type.STRING(50),
        Rendicion: type.STRING(50)
    })
}

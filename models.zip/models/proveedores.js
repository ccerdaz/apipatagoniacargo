module.exports = (sequelize, type) => {
    return sequelize.define('proveedores', {
        Id: {
            type: type.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        Empresa: type.STRING(80),
        Nombre: type.STRING(80),
        Contacto: type.STRING(100),
        Direccion: type.STRING(100),
        Comuna: type.STRING(20),
        Pais: type.STRING(50),
        Telefono: type.STRING(100),
        Horario: type.STRING(150),
    })
}
